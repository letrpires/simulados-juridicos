const DB_URL='data/questoes.json';
const LS_KEY='simulados_juridicos_estado_v1';
let questions=[]; let state=loadState(); let currentView='dashboard'; let session=[]; let currentIndex=0;
function today(){return new Date().toISOString().slice(0,10)}
function addDays(d,n){const x=new Date(d||today());x.setDate(x.getDate()+n);return x.toISOString().slice(0,10)}
function loadState(){try{return JSON.parse(localStorage.getItem(LS_KEY))||defaultState()}catch{return defaultState()}}
function defaultState(){return{answers:{},marked:{},xp:0,badges:[],sessions:[],settings:{theme:localStorage.getItem('theme')||''},lastSession:null,studySeconds:0}}
function save(){localStorage.setItem(LS_KEY,JSON.stringify(state))}
function qState(id){return state.answers[id]||{seen:false,correct:null,attempts:0,interval:1,lastReviewed:null,nextReview:null,history:[]}}
function setTheme(t){document.documentElement.dataset.theme=t;localStorage.setItem('theme',t);state.settings.theme=t;save();document.getElementById('themeToggle').textContent=t==='dark'?'☀️ Modo claro':'🌙 Modo escuro'}
async function init(){questions=await fetch(DB_URL).then(r=>r.json());setTheme(state.settings.theme|| (matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'));bindNav();render('dashboard')}
function bindNav(){document.querySelectorAll('.nav-btn[data-view]').forEach(b=>b.onclick=()=>render(b.dataset.view));document.getElementById('themeToggle').onclick=()=>setTheme(document.documentElement.dataset.theme==='dark'?'light':'dark');document.getElementById('continueBtn').onclick=()=>startSession({mode:'continue'})}
function render(view){currentView=view;document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.view===view));document.getElementById('viewTitle').textContent={dashboard:'Dashboard',study:'Estudar',review:'Revisão inteligente',library:'Biblioteca',settings:'Ajustes'}[view]||'Simulados';({dashboard:renderDashboard,study:renderStudy,review:renderReview,library:renderLibrary,settings:renderSettings}[view]||renderDashboard)()}
function stats(){const total=questions.length;const ans=Object.values(state.answers);const done=ans.filter(a=>a.seen).length;const ok=ans.filter(a=>a.correct===true).length;const err=ans.filter(a=>a.correct===false).length;const due=questions.filter(q=>{const s=qState(q.id);return s.nextReview&&s.nextReview<=today()}).length;return{total,done,ok,err,due,acc:done?Math.round(ok/done*100):0}}
function by(arr,key){return arr.reduce((m,x)=>{const k=x[key]||'Não identificado';m[k]=(m[k]||0)+1;return m},{})}
function renderDashboard(){const s=stats(); const byMod=Object.entries(by(questions,'modulo')).sort((a,b)=>b[1]-a[1]).slice(0,10); const max=Math.max(...byMod.map(x=>x[1]),1); document.getElementById('content').innerHTML=`<div class="grid"><div class="card stat"><span>Total</span><strong>${s.total}</strong></div><div class="card stat"><span>Respondidas</span><strong>${s.done}</strong></div><div class="card stat"><span>Taxa de acerto</span><strong>${s.acc}%</strong></div><div class="card stat"><span>Revisões vencidas</span><strong>${s.due}</strong></div><div class="card wide"><h3>Desempenho por módulo</h3><div class="chart">${byMod.map(([k,v])=>`<div class="bar" style="height:${Math.max(8,v/max*190)}px"><small>${k.replace('Informativos ','')}</small></div>`).join('')}</div></div><div class="card side"><h3>Atividade 30 dias</h3><div class="heatmap">${heatmap()}</div><p class="muted">XP: <b>${state.xp}</b></p><button class="primary-btn" onclick="startSession({})">Iniciar sessão</button></div><div class="card full"><h3>Últimas sessões</h3>${sessionTable()}</div></div>`}
function heatmap(){const counts={};state.sessions.forEach(s=>counts[s.date]=(counts[s.date]||0)+s.total);let out='';for(let i=29;i>=0;i--){const d=addDays(today(),-i);const c=counts[d]||0;out+=`<span class="heat ${c>20?'h3':c>5?'h2':c>0?'h1':''}" title="${d}: ${c} questões"></span>`}return out}
function sessionTable(){if(!state.sessions.length)return'<p>Nenhuma sessão registrada ainda.</p>';return`<table class="table"><tr><th>Data</th><th>Módulo</th><th>Resultado</th></tr>${state.sessions.slice(-8).reverse().map(s=>`<tr><td>${s.date}</td><td>${s.label||'Sessão'}</td><td>${s.correct}/${s.total}</td></tr>`).join('')}</table>`}

function uniqueSorted(vals){
  return [...new Set(vals.filter(v=>v!==undefined&&v!==null&&String(v).trim()!==''))]
    .sort((a,b)=>String(a).localeCompare(String(b),'pt-BR',{numeric:true}));
}
function escapeHtml(s){
  return (s||'').toString().replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}
function infoLabel(q){
  if(q.tipo==='edicao_extraordinaria') return `Ed. Extra ${q.informativo} STJ`;
  if(q.tipo==='informativo' && q.informativo) return `Info ${q.informativo} ${q.tribunal||''}`.trim();
  return q.fonte || q.modulo || '';
}
function optionList(values, selected, allLabel){
  return `<option value="">${allLabel}</option>` + values.map(v=>`<option value="${escapeHtml(v)}" ${v===selected?'selected':''}>${escapeHtml(v)}</option>`).join('');
}
let filterState={term:'',tribunal:'',categoria:'',modulo:'',info:'',status:''};
function syncFilterStateFromDom(){
  filterState.term=document.getElementById('search')?.value||filterState.term||'';
  filterState.tribunal=document.getElementById('tribunal')?.value||'';
  filterState.categoria=document.getElementById('cat')?.value||'';
  filterState.modulo=document.getElementById('mod')?.value||'';
  filterState.info=document.getElementById('info')?.value||'';
  filterState.status=document.getElementById('status')?.value||'';
}
function matchesStatus(q,status){
  if(!status) return true;
  const st=qState(q.id);
  if(status==='unseen') return !st.seen;
  if(status==='wrong') return st.seen && st.correct===false;
  if(status==='marked') return !!state.marked[q.id];
  if(status==='review') return !!(st.nextReview && st.nextReview<=today());
  return true;
}
function matchesFilters(q,ignore=''){
  const f=filterState;
  const texto=[q.enunciado,q.explicacao,q.fonte,q.modulo,q.disciplina,q.tema].join(' ').toLowerCase();
  if(ignore!=='term' && f.term && !texto.includes(f.term.toLowerCase())) return false;
  if(ignore!=='tribunal' && f.tribunal && q.tribunal!==f.tribunal) return false;
  if(ignore!=='categoria' && f.categoria && q.categoria!==f.categoria) return false;
  if(ignore!=='modulo' && f.modulo && q.modulo!==f.modulo) return false;
  if(ignore!=='info' && f.info && infoLabel(q)!==f.info) return false;
  if(ignore!=='status' && !matchesStatus(q,f.status)) return false;
  return true;
}
function filtered(){return questions.filter(q=>matchesFilters(q))}
function renderStudy(){
  const tribunais=uniqueSorted(questions.filter(q=>matchesFilters(q,'tribunal')).map(q=>q.tribunal));
  const cats=uniqueSorted(questions.filter(q=>matchesFilters(q,'categoria')).map(q=>q.categoria));
  const mods=uniqueSorted(questions.filter(q=>matchesFilters(q,'modulo')).map(q=>q.modulo));
  const infos=uniqueSorted(questions.filter(q=>matchesFilters(q,'info')).map(infoLabel));
  const total=filtered().length;
  document.getElementById('content').innerHTML=`
    <section class="card study-builder">
      <div class="study-head">
        <div>
          <h2>Monte sua sessão</h2>
          <p class="muted">Filtre por tribunal, categoria, módulo e informativo. As opções se ajustam automaticamente.</p>
        </div>
        <div class="pill-count">${total} questões</div>
      </div>
      <div class="filters">
        <input id="search" placeholder="Buscar enunciado, tema, fonte" value="${escapeHtml(filterState.term)}">
        <select id="tribunal">${optionList(tribunais,filterState.tribunal,'Todos tribunais')}</select>
        <select id="cat">${optionList(cats,filterState.categoria,'Todas categorias')}</select>
        <select id="mod">${optionList(mods,filterState.modulo,'Todos módulos')}</select>
        <select id="info">${optionList(infos,filterState.info,'Todos informativos/cadernos')}</select>
        <select id="status">
          <option value="" ${!filterState.status?'selected':''}>Todas</option>
          <option value="unseen" ${filterState.status==='unseen'?'selected':''}>Não respondidas</option>
          <option value="wrong" ${filterState.status==='wrong'?'selected':''}>Erradas</option>
          <option value="marked" ${filterState.status==='marked'?'selected':''}>Marcadas</option>
          <option value="review" ${filterState.status==='review'?'selected':''}>Revisão vencida</option>
        </select>
      </div>
      <div class="session-actions">
        <button class="primary btn-start" onclick="startSessionFromFilters()">Começar sessão</button>
      </div>
    </section>`;
  const search=document.getElementById('search');
  if(search){
    search.addEventListener('input',(e)=>{
      filterState.term=e.target.value;
      const totalAtual=filtered().length;
      const pill=document.querySelector('.pill-count');
      if(pill) pill.textContent=`${totalAtual} questões`;
    });
  }
  ['tribunal','cat','mod','info','status'].forEach(id=>{
    const el=document.getElementById(id);
    if(!el) return;
    el.onchange=()=>{
      syncFilterStateFromDom();
      if(id==='tribunal'){filterState.categoria='';filterState.modulo='';filterState.info=''}
      if(id==='cat'){filterState.modulo='';filterState.info=''}
      if(id==='mod'){filterState.info=''}
      renderStudy();
    };
  });
}

function startSessionFromFilters(){const label=document.getElementById('info')?.selectedOptions?.[0]?.text || document.getElementById('mod').value || document.getElementById('cat').value || 'Sessão personalizada';startSession({list:filtered(),label})}
function startSession(opts={}){let list=opts.list;let startAt=0;if(!list){if(opts.mode==='continue'&&state.lastSession?.ids?.length){list=state.lastSession.ids.map(id=>questions.find(q=>q.id===id)).filter(Boolean);startAt=list.findIndex(q=>!qState(q.id).seen);if(startAt<0){list=questions.filter(q=>!qState(q.id).seen).slice(0,30);startAt=0}}else{list=questions.filter(q=>!qState(q.id).seen).slice(0,30)}} session=list.slice(0,50); currentIndex=Math.min(startAt,Math.max(session.length-1,0)); state.lastSession={ids:session.map(q=>q.id)}; save(); renderQuestion()}
function renderQuestion(){if(!session.length){document.getElementById('content').innerHTML='<div class="card"><h3>Nenhuma questão encontrada.</h3></div>';return} if(currentIndex>=session.length){finishSession();return} const q=session[currentIndex], st=qState(q.id), pct=Math.round(currentIndex/session.length*100); document.getElementById('viewTitle').textContent='Sessão de estudo'; document.getElementById('content').innerHTML=`<div class="card question-card"><div class="progress-bar"><span style="width:${pct}%"></span></div><p class="eyebrow">Questão ${currentIndex+1} de ${session.length}</p><div class="question-meta"><span>${q.modulo}</span><span>•</span><span>${q.fonte||''}</span><span>•</span><span>${q.disciplina||''}</span></div><div class="question-text">${escapeHtml(q.enunciado)}</div><div class="answers"><button class="answer-btn" onclick="answer('C')">CERTO</button><button class="answer-btn" onclick="answer('E')">ERRADO</button></div><div class="pill-row" style="margin-top:12px"><button class="pill ${state.marked[q.id]?'active':''}" onclick="toggleMark('${q.id}')">⭐ Marcar</button><button class="pill" onclick="currentIndex++;renderQuestion()">Pular</button></div><div id="feedback"></div></div>`}
function answer(resp){const q=session[currentIndex];const correct=q.respostaCorreta===resp;let st=qState(q.id);st.seen=true;st.correct=correct;st.attempts=(st.attempts||0)+1;st.lastReviewed=today();st.interval=correct?Math.max(2,(st.interval||1)*2):1;st.nextReview=addDays(today(),st.interval);st.history=[...(st.history||[]),{date:today(),resp,correct}];state.answers[q.id]=st;state.xp+=(correct?10:3);save();document.querySelectorAll('.answer-btn').forEach(b=>{const val=b.textContent.trim().charAt(0);if(val===q.respostaCorreta){b.classList.add('correct')}else if(val===resp){b.classList.add('wrong')}b.disabled=true});document.getElementById('feedback').innerHTML=`<div class="feedback"><b>${correct?'✅ Acertou':'❌ Errou'}.</b> Gabarito: <b>${q.respostaCorreta==='C'?'CERTO':'ERRADO'}</b><br><br>${escapeHtml(q.explicacao||'Sem explicação cadastrada.')}<br><br><small>${q.fonte||''}</small><br><button class="primary-btn" style="margin-top:12px" onclick="currentIndex++;renderQuestion()">Próxima</button></div>`}
function toggleMark(id){state.marked[id]=!state.marked[id];save();renderQuestion()}
function finishSession(){const ids=session.map(q=>q.id);const correct=ids.filter(id=>qState(id).correct===true).length;state.sessions.push({date:today(),label:'Sessão',total:ids.length,correct});save();document.getElementById('content').innerHTML=`<div class="card question-card"><h2>Sessão concluída</h2><p>Você acertou <b>${correct}</b> de <b>${ids.length}</b>.</p><p>XP atual: <b>${state.xp}</b></p><button class="primary-btn" onclick="render('dashboard')">Ver dashboard</button></div>`}
function renderReview(){const due=questions.filter(q=>{const s=qState(q.id);return s.nextReview&&s.nextReview<=today()});document.getElementById('content').innerHTML=`<div class="card"><h3>Revisões de hoje</h3><p>${due.length} questão(ões) vencidas para revisão.</p><button class="primary-btn" onclick='startSession({list:${JSON.stringify(due.map(q=>q.id))}.map(id=>questions.find(q=>q.id===id)).filter(Boolean),label:"Revisão"})'>Iniciar revisão</button></div>`}
function renderLibrary(){const cats=Object.entries(by(questions,'categoria')).sort();const mods=Object.entries(by(questions,'modulo')).sort();document.getElementById('content').innerHTML=`<div class="grid"><div class="card side"><h3>Categorias</h3>${cats.map(([k,v])=>`<p><b>${k}</b><br><span class="eyebrow">${v} questões</span></p>`).join('')}</div><div class="card wide"><h3>Módulos</h3><table class="table">${mods.map(([k,v])=>`<tr><td>${k}</td><td>${v}</td></tr>`).join('')}</table></div></div>`}
function renderSettings(){document.getElementById('content').innerHTML=`<div class="card"><h3>Dados e progresso</h3><p>Seu progresso fica salvo neste navegador.</p><button class="secondary-btn" onclick="exportProgress()">Exportar progresso</button> <button class="danger-btn" onclick="resetProgress()">Resetar tudo</button><br><br><textarea id="importBox" placeholder="Cole aqui um JSON de progresso para importar" style="width:100%;min-height:120px;border-radius:14px;padding:12px;background:var(--surface);color:var(--text);border:1px solid var(--line)"></textarea><br><button class="primary-btn" onclick="importProgress()">Importar progresso</button></div>`}
function exportProgress(){const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='progresso-simulados.json';a.click()}
function importProgress(){try{state=JSON.parse(document.getElementById('importBox').value);save();alert('Importado com sucesso.');render('dashboard')}catch(e){alert('JSON inválido.')}}
function resetProgress(){if(confirm('Tem certeza?')&&confirm('Confirma apagar todo o progresso?')){state=defaultState();save();render('dashboard')}}
function escapeHtml(s){return String(s||'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m])).replace(/\n/g,'<br>')}
init().catch(e=>{document.body.innerHTML='<pre style="padding:24px">Erro ao carregar data/questoes.json:\n'+e+'</pre>'})



/* === Revisão inteligente v1 === */
function smartLevel(st){
  if(!st || !st.seen) return {label:'Não visto', cls:'level-new'};
  if(st.correct===false) return {label:'Aprendendo', cls:'level-learning'};
  if((st.interval||1) >= 15) return {label:'Dominado', cls:'level-mastered'};
  return {label:'Revisando', cls:'level-reviewing'};
}
function reviewDueList(){
  return questions.filter(q=>{
    const st=qState(q.id);
    return st.nextReview && st.nextReview <= today();
  });
}
function manualMarkedList(){
  return questions.filter(q=>state.marked[q.id]);
}
function scheduleQuestionReview(q, correct){
  let st=qState(q.id);

  st.seen = true;
  st.correct = correct;
  st.attempts = (st.attempts || 0) + 1;
  st.lastReviewed = today();

  if(!st.history) st.history = [];
  st.history.push({
    date: today(),
    correct: correct
  });

  if(correct){
    const atual = st.interval || 1;
    st.interval = Math.min(atual * 2, 30);
    st.nextReview = addDays(today(), st.interval);
    state.xp = (state.xp || 0) + 10;
  }else{
    st.interval = 1;
    st.nextReview = addDays(today(), 1);
    state.xp = (state.xp || 0) + 3;
    state.marked[q.id] = true;
  }

  state.answers[q.id] = st;
  state.lastSession = {
    ids: session.map(x=>x.id),
    currentIndex: Math.min(currentIndex + 1, session.length - 1),
    updatedAt: new Date().toISOString()
  };

  save();
  return st;
}
function toggleReviewLater(){
  const q = session[currentIndex];
  if(!q) return;

  const isMarked = !!state.marked[q.id];

  if(isMarked){
    delete state.marked[q.id];
  }else{
    state.marked[q.id] = true;
    let st = qState(q.id);
    st.nextReview = today();
    st.interval = st.interval || 1;
    state.answers[q.id] = st;
  }

  save();
  renderQuestion();
}
function renderReviewSmart(){
  const due = reviewDueList();
  const marked = manualMarkedList();
  const merged = [...new Map([...due, ...marked].map(q=>[q.id,q])).values()];

  document.getElementById('content').innerHTML = `
    <section class="card study-builder">
      <div class="study-head">
        <div>
          <h2>Revisão inteligente</h2>
          <p class="muted">Questões erradas, marcadas ou vencidas na repetição espaçada aparecem aqui.</p>
        </div>
        <div class="pill-count">${merged.length} pendentes</div>
      </div>

      <div class="review-grid">
        <div class="review-stat">
          <strong>${due.length}</strong>
          <span>vencidas hoje</span>
        </div>
        <div class="review-stat">
          <strong>${marked.length}</strong>
          <span>marcadas</span>
        </div>
        <div class="review-stat">
          <strong>${state.xp || 0}</strong>
          <span>XP</span>
        </div>
      </div>

      <div class="session-actions">
        <button class="primary btn-start" onclick="startSession({list:reviewDueList(),label:'Revisão vencida'})">Revisar vencidas</button>
        <button class="ghost" onclick="startSession({list:manualMarkedList(),label:'Marcadas para revisar'})">Revisar marcadas</button>
        <button class="ghost" onclick="startSession({list:[...new Map([...reviewDueList(),...manualMarkedList()].map(q=>[q.id,q])).values()],label:'Revisão inteligente'})">Revisar tudo</button>
      </div>
    </section>

    <section class="card">
      <h3>Como funciona</h3>
      <p class="muted">
        Ao errar, a questão volta para revisão em 1 dia e fica marcada.
        Ao acertar, o intervalo dobra progressivamente até 30 dias.
        O botão “Revisar depois” envia a questão para esta tela.
      </p>
    </section>
  `;
}
function render(view){
  currentView=view;
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
  const titleMap={dashboard:'Dashboard',study:'Estudar',review:'Revisão',library:'Biblioteca',settings:'Ajustes'};
  const title=document.getElementById('viewTitle');
  if(title) title.textContent=titleMap[view]||'Dashboard';

  if(view==='dashboard') return renderDashboard();
  if(view==='study') return renderStudy();
  if(view==='review') return renderReviewSmart();
  if(view==='library' && typeof renderLibrary==='function') return renderLibrary();
  if(view==='settings' && typeof renderSettings==='function') return renderSettings();

  return renderDashboard();
}
function renderQuestion(){
  if(!session.length){
    document.getElementById('content').innerHTML='<div class="card"><h3>Nenhuma questão encontrada.</h3><p class="muted">Ajuste os filtros e tente novamente.</p></div>';
    return;
  }

  const q = session[currentIndex];
  const st = qState(q.id);
  const lvl = smartLevel(st);
  const marked = !!state.marked[q.id];
  const prog = Math.round(((currentIndex+1)/session.length)*100);

  document.getElementById('content').innerHTML = `
    <section class="question-card card">
      <div class="progress"><span style="width:${prog}%"></span></div>

      <div class="q-meta">
        <span>Questão ${currentIndex+1} de ${session.length}</span>
        <span>${q.modulo || ''}</span>
        <span>${q.fonte || ''}</span>
        <span class="level-pill ${lvl.cls}">${lvl.label}</span>
      </div>

      ${(q.disciplina || q.tema) ? `
        <div class="q-taxonomy">
          ${q.disciplina ? `<span>${q.disciplina}</span>` : ''}
          ${q.tema ? `<span>${q.tema}</span>` : ''}
        </div>` : ''
      }

      <h2 class="q-text">${q.enunciado || 'Sem enunciado cadastrado.'}</h2>

      <div class="answers">
        <button class="answer-btn" onclick="answer('C')">CERTO</button>
        <button class="answer-btn" onclick="answer('E')">ERRADO</button>
      </div>

      <div class="q-actions">
        <button class="ghost" onclick="toggleReviewLater()">${marked ? '⭐ Remover revisão' : '⭐ Revisar depois'}</button>
        <button class="ghost" onclick="nextQuestion()">Pular</button>
      </div>

      <div id="feedback"></div>
    </section>
  `;
}
function answer(resp){
  const q = session[currentIndex];
  const correct = q.respostaCorreta === resp;
  const st = scheduleQuestionReview(q, correct);

  document.querySelectorAll('.answer-btn').forEach(b=>{
    const val = b.textContent.trim().charAt(0);
    if(val === q.respostaCorreta){
      b.classList.add('correct');
    }else if(val === resp){
      b.classList.add('wrong');
    }
    b.disabled = true;
  });

  const status = correct ? '✅ Acertou.' : `❌ Errou. Gabarito: ${q.respostaCorreta === 'C' ? 'CERTO' : 'ERRADO'}`;
  const agendada = st.nextReview ? `Próxima revisão: ${st.nextReview}` : '';

  document.getElementById('feedback').innerHTML = `
    <div class="feedback ${correct ? 'ok' : 'bad'}">
      <h3>${status}</h3>
      <p class="muted">${agendada}</p>
      <div class="explanation">${q.explicacao || 'Sem explicação cadastrada.'}</div>
      ${q.referencia ? `<p class="source-ref">${q.referencia}</p>` : ''}
      <button class="primary" onclick="nextQuestion()">Próxima questão</button>
    </div>
  `;
}
function nextQuestion(){
  if(currentIndex < session.length - 1){
    currentIndex++;
    if(state.lastSession){
      state.lastSession.currentIndex = currentIndex;
      state.lastSession.updatedAt = new Date().toISOString();
      save();
    }
    renderQuestion();
  }else{
    const ids = session.map(q=>q.id);
    const ok = ids.filter(id=>state.answers[id]?.correct===true).length;
    const total = ids.length;

    state.sessions.push({
      date: today(),
      label: state.lastSession?.label || 'Sessão',
      correct: ok,
      total: total
    });
    save();

    document.getElementById('content').innerHTML = `
      <section class="card finish-card">
        <h2>Sessão concluída</h2>
        <p class="muted">Você respondeu ${total} questão(ões).</p>
        <div class="review-grid">
          <div class="review-stat"><strong>${ok}</strong><span>acertos</span></div>
          <div class="review-stat"><strong>${total-ok}</strong><span>erros</span></div>
          <div class="review-stat"><strong>${Math.round((ok/Math.max(total,1))*100)}%</strong><span>aproveitamento</span></div>
        </div>
        <div class="session-actions">
          <button class="primary" onclick="render('study')">Nova sessão</button>
          <button class="ghost" onclick="render('review')">Ir para revisão</button>
        </div>
      </section>
    `;
  }
}
